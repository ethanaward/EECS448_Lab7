#ifndef TEST_H
#define TEST_H

#include <iostream>
#include <vector>
#include "Node.h"
#include "LinkedList.h"

class Test {
  public:

  Test();

  ~Test();

  bool test1();

  bool test2();

  bool test3();

  bool test4();

  bool test5();

  bool test6();

  bool test7();

  bool test8();

  bool test9();

  bool test10();

  bool test11();

  bool test12();

  bool test13();

  bool test14();


};

#endif
